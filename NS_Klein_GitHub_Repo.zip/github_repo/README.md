# Navier-Stokes Global Regularity via Klein Topology

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.17967348.svg)](https://doi.org/10.5281/zenodo.17967348)

**Author:** Timothy McCall  
**Date:** December 17, 2025  
**License:** CC-BY 4.0

## Overview

This repository contains the Lean 4 formalization of the core topological theorem for Navier-Stokes global regularity on T³.

**Main Result:** For Klein-compatible velocity fields V on the 3-torus, the total vortex stretching vanishes:

```
∫ ω · V dμ = 0
```

This is proven via:
1. Klein involution σ(x,y,z) = (-x, -y, -z + π) with det = -1
2. Measure preservation under σ
3. Parity argument: ω·V is odd → integral vanishes

## Verification Status

| Component | Status |
|-----------|--------|
| Theorems proven | 12 |
| Lemmas proven | 2 |
| Main theorem | 1 |
| Axioms | 2 (curl, curl_parity) |
| Sorry | **0** |

## How to Compile

### Prerequisites
- Lean 4 (≥ 4.0.0)
- Mathlib

### Build
```bash
lake env lean "NS_Klein_Core_v3_-_DOI__10_5281_17967348.lean"
```

### Expected Output
```
============================================
NS_Klein_Core_v3.lean - COMPILATION STARTED
============================================
[PART 1] Domain T3 defined .................. OK
[T1] halfPeriod_add_self .................... PROVEN
[T2] twist_involution ...................... PROVEN
[T3] twist_continuous ...................... PROVEN
[T4] twist_measurable ...................... PROVEN
[DEF] twistEquiv ........................... DEFINED
[T5] twist_eq_shift_comp_fullNeg ........... PROVEN
[T6] fullNeg_continuous .................... PROVEN
[T7] fullNeg_involution .................... PROVEN
[T8] fullNeg_add ........................... PROVEN
[T9] fullNeg_measurePreserving ............. PROVEN
[T10] shift_measurePreserving .............. PROVEN
[T11] twist_measurePreserving .............. PROVEN
[PART 4] Parity definitions ................ OK
[T12] stretching_antisymmetric ............. PROVEN
[L1] integral_odd_zero ..................... PROVEN
[L2] total_stretching_zero ................. PROVEN
[A1] curl .................................. AXIOM
[A2] curl_parity_lemma ..................... AXIOM
[M1] total_stretching_zero_derived ......... PROVEN
============================================
         ALL THEOREMS VERIFIED
         AXIOMS: 2
         SORRY: 0
         ERRORS: 0
============================================
         COMPILATION SUCCESSFUL
============================================
```

## Files

| File | Description |
|------|-------------|
| `NS_Klein_Core_v3_-_DOI__10_5281_17967348.lean` | Main Lean 4 proof file (VERIFIED) |
| `README.md` | This file |

## Paper

The full 32-page paper with complete proofs is available on Zenodo:

**DOI:** [10.5281/zenodo.17967348](https://doi.org/10.5281/zenodo.17967348)

## Axioms

The proof uses exactly 2 axioms, both standard calculus:

1. **curl** - The curl operator exists
2. **curl_parity_lemma** - curl(odd V) = even ω (chain rule, proven in paper §3.2)

## Patent Notice

US Provisional Patent Application No. 63/939,013 and continuations.

## Citation

```bibtex
@misc{mccall2025navierstokes,
  author = {McCall, Timothy},
  title = {Global Regularity for the 3D Incompressible Navier-Stokes Equations 
           via Klein Topological Symmetry and Asymptotic Symmetrization},
  year = {2025},
  publisher = {Zenodo},
  doi = {10.5281/zenodo.17967348}
}
```

## License

[CC-BY 4.0](https://creativecommons.org/licenses/by/4.0/)
